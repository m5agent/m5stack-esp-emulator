import sys, os, json, binascii, M5
import helper
from unit import PIRUnit
assert '/pkg-smoke-9d066d96dd9441b092bb8454395924d1' in sys.path
M5.begin()
M5.Display.fillScreen(0x255588)
pir=PIRUnit((1, 2))
with open('assets/data.dat','rb') as f:
 data=binascii.hexlify(f.read()).decode()
print('PKG_SMOKE_READY', helper.transform(5), data, int(pir.get_status()), os.getcwd(), helper.__file__)
