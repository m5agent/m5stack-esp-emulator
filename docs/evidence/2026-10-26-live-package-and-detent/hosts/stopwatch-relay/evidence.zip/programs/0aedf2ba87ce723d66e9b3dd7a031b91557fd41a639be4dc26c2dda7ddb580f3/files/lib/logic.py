import helper
VALUE = 5
def calculate(value):
 return helper.transform(value) + VALUE
