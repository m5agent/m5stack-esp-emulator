import helper
VALUE = 7
def calculate(value):
 return helper.transform(value) + VALUE
