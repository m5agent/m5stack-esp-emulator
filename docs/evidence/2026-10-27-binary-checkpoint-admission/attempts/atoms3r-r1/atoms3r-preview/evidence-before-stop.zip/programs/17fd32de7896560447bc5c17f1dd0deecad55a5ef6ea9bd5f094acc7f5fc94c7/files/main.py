import sys,json,time
import M5
from unit import PIRUnit
assert '/m5-binary-admission-085e69fbd8264d4c8cd381527a0abcb2' in sys.path, 'VM nonce lost'
M5.begin()
screen=M5.Display
screen.setBrightness(255)
screen.fillScreen(0)
unit=PIRUnit((1,2))
screen.fillRect(screen.width()//2-4,screen.height()//2-4,8,8,65280)
print('BINARY_ADMISSION '+json.dumps({'kind':'ready','nonce':'085e69fbd8264d4c8cd381527a0abcb2','phase':'B'}))
sequence=0
previous=None
while True:
 M5.update()
 motion=bool(unit.get_status())
 if motion != previous:
  screen.fillRect(4,4,8,8,0xFFFFFF if motion else 0)
  previous=motion
 sequence+=1
 print('BINARY_ADMISSION '+json.dumps({'kind':'sample','nonce':'085e69fbd8264d4c8cd381527a0abcb2','phase':'B','sequence':sequence,'motion':motion}))
 time.sleep_ms(200)
