import sys,json,time
import M5
from unit import PIRUnit
assert '/m5-binary-admission-1437145df1bb406b9cc91cf4f6473cfd' not in sys.path
sys.path.append('/m5-binary-admission-1437145df1bb406b9cc91cf4f6473cfd')
M5.begin()
screen=M5.Display
screen.setBrightness(255)
screen.fillScreen(0)
unit=PIRUnit((1,2))
screen.fillRect(screen.width()//2-4,screen.height()//2-4,8,8,16711680)
print('BINARY_ADMISSION '+json.dumps({'kind':'ready','nonce':'1437145df1bb406b9cc91cf4f6473cfd','phase':'A'}))
sequence=0
previous=None
while True:
 M5.update()
 motion=bool(unit.get_status())
 if motion != previous:
  screen.fillRect(screen.width()//2-4,screen.height()//2+16,8,8,0xFFFFFF if motion else 0)
  previous=motion
 sequence+=1
 print('BINARY_ADMISSION '+json.dumps({'kind':'sample','nonce':'1437145df1bb406b9cc91cf4f6473cfd','phase':'A','sequence':sequence,'motion':motion}))
 time.sleep_ms(200)
