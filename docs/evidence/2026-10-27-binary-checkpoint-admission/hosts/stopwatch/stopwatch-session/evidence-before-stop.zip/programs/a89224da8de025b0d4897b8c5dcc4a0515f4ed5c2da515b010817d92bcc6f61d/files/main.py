import sys,json,time
import M5
from unit import PIRUnit
assert '/m5-binary-admission-bb6ba2309f104f96962c27182174a347' not in sys.path
sys.path.append('/m5-binary-admission-bb6ba2309f104f96962c27182174a347')
M5.begin()
screen=M5.Display
screen.setBrightness(255)
screen.fillScreen(0)
unit=PIRUnit((11,10))
screen.fillRect(screen.width()//2-4,screen.height()//2-4,8,8,16711680)
print('BINARY_ADMISSION '+json.dumps({'kind':'ready','nonce':'bb6ba2309f104f96962c27182174a347','phase':'A'}))
sequence=0
previous=None
while True:
 M5.update()
 motion=bool(unit.get_status())
 if motion != previous:
  screen.fillRect(screen.width()//2-4,screen.height()//2+16,8,8,0xFFFFFF if motion else 0)
  previous=motion
 sequence+=1
 print('BINARY_ADMISSION '+json.dumps({'kind':'sample','nonce':'bb6ba2309f104f96962c27182174a347','phase':'A','sequence':sequence,'motion':motion}))
 time.sleep_ms(200)
