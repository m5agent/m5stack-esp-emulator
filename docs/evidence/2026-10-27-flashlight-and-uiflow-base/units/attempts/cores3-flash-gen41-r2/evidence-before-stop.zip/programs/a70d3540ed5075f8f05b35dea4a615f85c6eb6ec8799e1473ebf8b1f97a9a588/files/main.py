import sys,os,json,utime,hashlib,binascii
import M5
from machine import Pin
import official_flash
assert '/m5-flash-bf74a089905a495681f637ffeab8e136' in sys.path, 'VM nonce lost'
assert official_flash.__file__ == os.getcwd()+'/official_flash.py', 'stale driver path'
with open(official_flash.__file__,'rb') as f:
 original=f.read()
assert len(original)==3639 and binascii.hexlify(hashlib.sha256(original).digest()).decode()=='10546386ee156034c268404e96f4d086b88c52254da1fcd2aa19130ce2f6629f', 'driver bytes changed'
M5.begin()
s=M5.Display
s.setBrightness(255)
s.fillScreen(0)
en=Pin(2,Pin.OUT,value=0)
utime.sleep_us(600)
flash=official_flash.FlashLightUnit((1,2))
utime.sleep_us(600)
flash.flash(1,1,False)

utime.sleep_us(600)
level=int(en.value())
s.fillRect(s.width()//2-4,s.height()//2-4,8,8,0xFFFFFF if level else 0)
print('FLASHLIGHT_GUEST '+json.dumps({'phase':'original-short','nonce':'bf74a089905a495681f637ffeab8e136','en':level,'driver_sha256':'10546386ee156034c268404e96f4d086b88c52254da1fcd2aa19130ce2f6629f','driver_file':official_flash.__file__}))
