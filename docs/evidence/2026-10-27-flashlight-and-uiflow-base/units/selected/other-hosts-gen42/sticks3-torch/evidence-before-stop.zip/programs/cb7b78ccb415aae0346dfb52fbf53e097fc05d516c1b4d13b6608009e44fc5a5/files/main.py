import sys,os,json,utime,hashlib,binascii
import M5
from machine import Pin
import official_flash
assert '/m5-flash-c97b9eb496454b259ddbc5fe9cc9605d' in sys.path, 'VM nonce lost'
assert official_flash.__file__ == os.getcwd()+'/official_flash.py', 'stale driver path'
with open(official_flash.__file__,'rb') as f:
 original=f.read()
assert len(original)==3639 and binascii.hexlify(hashlib.sha256(original).digest()).decode()=='10546386ee156034c268404e96f4d086b88c52254da1fcd2aa19130ce2f6629f', 'driver bytes changed'
M5.begin()
s=M5.Display
s.setBrightness(255)
s.fillScreen(0)
en=Pin(9,Pin.OUT,value=0)
utime.sleep_us(600)
en.value(1)

utime.sleep_us(600)
level=int(en.value())
s.fillRect(s.width()//2-4,s.height()//2-4,8,8,0xFFFFFF if level else 0)
print('FLASHLIGHT_GUEST '+json.dumps({'phase':'steady-on','nonce':'c97b9eb496454b259ddbc5fe9cc9605d','en':level,'driver_sha256':'10546386ee156034c268404e96f4d086b88c52254da1fcd2aa19130ce2f6629f','driver_file':official_flash.__file__}))
