_preview_phase='C'
import sys,json,time,binascii
import M5
from machine import I2C, Pin
from unit import EncoderUnit, Encoder8Unit, JoystickUnit
from logic import feedback
assert '/m5-preview-controls-450fde130f684860928a17790c531ac1' in sys.path, 'MicroPython VM nonce lost'
with open('settings.json') as stream:
 config = json.load(stream)
with open('assets/state.bin', 'rb') as stream:
 resource = stream.read()
assert resource == b'\x00\xff\x01\x80\r\nM5', 'resource bytes changed'
resource_hex = binascii.hexlify(resource).decode()
phase = globals().get('_preview_phase', config['phase'])
M5.begin()
screen = M5.Display
screen.setBrightness(255)
screen.fillScreen(0)
screen.setTextSize(1)
screen.setTextColor(0xFFFFFF, 0)
bus = I2C(0, scl=Pin(10), sda=Pin(9), freq=100000)
scan = sorted(bus.scan())
assert scan == [64,65,82], 'HUB bus leaked or wrong addresses'
encoder = EncoderUnit(bus, 0x40)
eight = Encoder8Unit(bus, 0x41)
joystick = JoystickUnit(bus, 0x52)
print('PREVIEW_CONTROLS '+json.dumps({'kind':'ready','nonce':config['nonce'],'phase':phase,'scan':scan,'resource_hex':resource_hex}))
sequence = 0
last_colors = None
while True:
 M5.update()
 e = {'counter':encoder.get_rotary_value(),'pressed':bool(encoder.get_button_status())}
 b = {'counters':[eight.get_counter_value(i) for i in range(1,9)],'pressed':[bool(eight.get_button_status(i)) for i in range(1,9)],'switch_on':bool(eight.get_switch_status())}
 j = {'x_raw':joystick.get_x_raw(),'y_raw':joystick.get_y_raw(),'button_raw':int(joystick.get_button_status())}
 colors = feedback(phase,e['pressed'],b['pressed'])
 if colors != last_colors:
  encoder.fill_color(colors[0])
  for channel in range(1,9):
   eight.set_led_rgb(channel,colors[1])
  # Original public register helper reaches the separate ninth LED triplet.
  eight.write_reg_data(0x88,list(colors[1].to_bytes(3,'big')))
  last_colors = colors
 sequence += 1
 screen.fillRect(0,0,screen.width(),48,0)
 screen.setCursor(4,4)
 screen.print('ENC %d %d' % (e['counter'],int(e['pressed'])))
 screen.setCursor(4,18)
 screen.print('8ENC %d %d' % (b['counters'][0],int(b['pressed'][0])))
 screen.setCursor(4,32)
 screen.print('JOY %d %d' % (j['x_raw'],j['y_raw']))
 screen.fillRect(screen.width()//2-4,screen.height()//2-4,8,8,{'A':0xFF0000,'B':0x00FF00,'C':0x0000FF}[phase])
 print('PREVIEW_CONTROLS '+json.dumps({'kind':'sample','nonce':config['nonce'],'phase':phase,'sequence':sequence,'resource_hex':resource_hex,'encoder':e,'eight':b,'joystick':j,'written':{'encoder':[colors[0]]*2,'eight':[colors[1]]*9}}))
 time.sleep_ms(200)
