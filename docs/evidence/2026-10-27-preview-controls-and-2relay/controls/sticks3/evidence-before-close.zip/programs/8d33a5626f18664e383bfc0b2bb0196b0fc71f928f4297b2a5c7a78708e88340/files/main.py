import sys,json
sys.path.append('/m5-preview-controls-450fde130f684860928a17790c531ac1')
print('PREVIEW_CONTROLS '+json.dumps({'kind':'seed','nonce':'450fde130f684860928a17790c531ac1'}))
