import sys,json
sys.path.append('/m5-preview-controls-6317b3de5af04a8d899936b51447b15f')
print('PREVIEW_CONTROLS '+json.dumps({'kind':'seed','nonce':'6317b3de5af04a8d899936b51447b15f'}))
