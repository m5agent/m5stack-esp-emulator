def feedback(phase, encoder_pressed, buttons):
 color = {'A':0xFF0000,'B':0x00FF00,'C':0x0000FF}[phase]
 return (color if encoder_pressed else 0,color if any(buttons) else 0)
