import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-fd18c23abbb8494193deeaac89e569e2')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'fd18c23abbb8494193deeaac89e569e2','builtin_compatible':True,'builtin_source_attested':False}))
