import os,sys,json,time,binascii,hashlib
import M5
from machine import Pin
import relay2_official
assert '/m5-preview-relay2-fd18c23abbb8494193deeaac89e569e2' in sys.path, 'MicroPython VM nonce lost'
with open('settings.json') as stream:
 config = json.load(stream)
with open('assets/state.bin','rb') as stream:
 resource = stream.read()
assert resource == b'\x00\xff\x01\x80\r\nM5', 'resource bytes changed'
cwd = os.getcwd()
assert relay2_official.__file__ == cwd + '/relay2_official.py', 'stale or frozen driver module'
with open(relay2_official.__file__,'rb') as stream:
 driver_bytes = stream.read()
driver_hash = binascii.hexlify(hashlib.sha256(driver_bytes).digest()).decode()
assert len(driver_bytes) == 1512 and driver_hash == 'db05e974f2cd558c4fbaef85958b82730a9bcae1b21eb9646371bea7e6f273c5', 'official source bytes changed'
phase = config['phase']
white,yellow = config['pins']['white'],config['pins']['yellow']
initial_pads = [int(Pin(white).value()),int(Pin(yellow).value())]
M5.begin()
screen = M5.Display
screen.setBrightness(255)
screen.fillScreen(0)
screen.setTextColor(0xFFFFFF,0)
screen.setTextSize(1)
relay = relay2_official.Relay2Unit((white,yellow))
levels = [0,0] if phase == 'interactive' else [int(c) for c in phase]
relay.set_relay_cntrl(1,levels[0])
relay.set_relay_cntrl(2,levels[1])
identity = {'nonce':config['nonce'],'phase':phase,'device':config['device'],'pins':[white,yellow],
 'cwd':cwd,'driver_file':relay2_official.__file__,'driver_sha256':driver_hash,'driver_size':len(driver_bytes),'resource_hex':binascii.hexlify(resource).decode()}
ready = dict(identity)
ready['kind'] = 'ready'
print('PREVIEW_RELAY2 '+json.dumps(ready))
sequence = 0
events = 0
last_touch = False
last_a = False
last_b = False
gray = 0
last_drawn = None
while True:
 M5.update()
 if phase == 'interactive':
  if config['control'] == 'touch-halves':
   pressed = bool(M5.Touch.getCount())
   if pressed and not last_touch:
    channel = 0 if M5.Touch.getX() < screen.width()//2 else 1
    levels[channel] = 1-levels[channel]
    events += 1
   last_touch = pressed
  else:
   a = bool(M5.BtnA.isPressed())
   if config['control'] == 'button-a-gray-cycle':
    if a and not last_a:
     gray = (gray+1)%4
     levels = [[0,0],[1,0],[1,1],[0,1]][gray]
     events += 1
   else:
    b = bool(M5.BtnB.isPressed())
    if a and not last_a:
     levels[0] = 1-levels[0]
     events += 1
    if b and not last_b:
     levels[1] = 1-levels[1]
     events += 1
    last_b = b
   last_a = a
 # Repeat both original-driver writes continuously. Unchanged pad levels must
 # not be counted as transitions or leak to the other independent channel.
 relay.set_relay_cntrl(1,levels[0])
 relay.set_relay_cntrl(2,levels[1])
 pads = [int(Pin(white).value()),int(Pin(yellow).value())]
 statuses = [relay.get_relay_status(1),relay.get_relay_status(2)]
 assert pads == levels and statuses == [bool(n) for n in levels], 'cross-channel pad mismatch'
 if levels != last_drawn:
  screen.fillRect(0,0,screen.width(),42,0)
  screen.setCursor(4,4)
  screen.print('RELAY1 %d RELAY2 %d' % (levels[0],levels[1]))
  screen.setCursor(4,20)
  screen.print('U131 '+phase)
  color = (0, 65280, 16711680, 255)[levels[0]*2+levels[1]]
  screen.fillRect(screen.width()//2-4,screen.height()//2-4,8,8,color)
  last_drawn = list(levels)
 sequence += 1
 sample = dict(identity)
 sample.update({'kind':'sample','sequence':sequence,'events':events,'levels':[bool(n) for n in levels],
  'pads':pads,'statuses':statuses,'initial_pads':initial_pads,'written':[int(n) for n in levels]})
 print('PREVIEW_RELAY2 '+json.dumps(sample))
 time.sleep_ms(200)
