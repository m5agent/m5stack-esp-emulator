import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-8729b5822f264d14aa3852c0f50681c0')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'8729b5822f264d14aa3852c0f50681c0','builtin_compatible':True,'builtin_source_attested':False}))
