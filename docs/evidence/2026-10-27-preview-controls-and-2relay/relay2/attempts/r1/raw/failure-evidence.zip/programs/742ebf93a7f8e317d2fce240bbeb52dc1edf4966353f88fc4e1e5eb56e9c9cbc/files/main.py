import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-bd0404023f27432c83ae671373ef3efe')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'bd0404023f27432c83ae671373ef3efe','builtin_compatible':True,'builtin_source_attested':False}))
