import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-e7af5dac8cba46eab48b552f383dff77')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'e7af5dac8cba46eab48b552f383dff77','builtin_compatible':True,'builtin_source_attested':False}))
