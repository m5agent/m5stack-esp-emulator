import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-f6fc57b413e4425da8c9e14aef60220a')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'f6fc57b413e4425da8c9e14aef60220a','builtin_compatible':True,'builtin_source_attested':False}))
