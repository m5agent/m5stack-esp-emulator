import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-1940934c721f4dc4a45b626bfc588521')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'1940934c721f4dc4a45b626bfc588521','builtin_compatible':True,'builtin_source_attested':False}))
