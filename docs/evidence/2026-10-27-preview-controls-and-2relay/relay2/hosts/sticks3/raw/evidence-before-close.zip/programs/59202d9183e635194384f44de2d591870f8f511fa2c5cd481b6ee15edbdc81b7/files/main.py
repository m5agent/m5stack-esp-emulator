import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-0e2bc9e4d69d4ec59dec6eb1bc250d14')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'0e2bc9e4d69d4ec59dec6eb1bc250d14','builtin_compatible':True,'builtin_source_attested':False}))
