import sys,json
from unit import Relay2Unit
assert callable(Relay2Unit.set_relay_cntrl) and callable(Relay2Unit.get_relay_status)
sys.path.append('/m5-preview-relay2-e65445751bf4483c800567e4d5217e58')
print('PREVIEW_RELAY2 '+json.dumps({'kind':'seed','nonce':'e65445751bf4483c800567e4d5217e58','builtin_compatible':True,'builtin_source_attested':False}))
