import helper
VALUE = 3
def calculate(value):
 return helper.transform(value) + VALUE
