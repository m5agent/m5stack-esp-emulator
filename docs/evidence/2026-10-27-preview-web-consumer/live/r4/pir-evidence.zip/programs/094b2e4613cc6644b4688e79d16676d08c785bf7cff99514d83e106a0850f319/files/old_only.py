VALUE = 'A-only'
